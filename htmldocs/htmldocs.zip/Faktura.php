<?php session_start(); ?>
<!doctype html>
<?php include_once("DB.php"); ?>
<html>
<head>
<link rel="stylesheet" type="text/css" media="screen" href="../css/45529.css">
<link rel="shortcut icon" type="image/ico" href="../img/logo.png"/>
<link rel="stylesheet" type="text/css" href="../css/new.css"/>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge;chrome=1" />
<title>Acura</title>
</head>
<body class="wall">
	<header>
	<div class ="frame">
		<div class="logo">
			<a href="../Index.php"><img src="../img/logo.png" alt="Reweral-Auto" title="Reweral-Auto" class="logo"></a>
		</div>
		<div class="Login">
			<ul class="login-ul">
				<li>
					<?php  
						if(isset($_SESSION["name"]))
						{
							echo "<a href='Cabinet.php'>Hello, ".$_SESSION["name"]."</a>";
							echo (
								"<form method='post' action='Cabinet.php'>
									<div>
										<button name='logout' type='submit'>Log out</button>
									</div>
								</form>");
							if(isset($_POST["logout"]))
							{
								header('Location: ../Index.php');
								session_destroy();								
							}							
						}
						if(!isset($_SESSION["name"]))
						{
							echo "<a href='Login.php'>Log In</a>";
											
					?>
					<br>
				</li>
				<li>
					<?php
						echo "<a href='SignUp.php'>Sign Up</a>";
						}
					?>
				</li>
			</ul>
		</div>
	</div>
	</header>
	<?php 
		$session_name = $_SESSION["name"];
		$DB = mysqli_query($linkToBd,"SELECT * FROM Register WHERE Email = '$session_name' ");
		$dataForUser = mysqli_fetch_assoc($DB);
		$name = $dataForUser["Name"];
		$surname = $dataForUser["Surname"];
	?>	
<div class = "Forms">
			<form class="input" method="post" action="PersonalData.php">
					<div class="wrapper">
						<div style="display: flex; justify-content: space-around;">
							<div style="padding-left: 20px;">	
								<h3>Imię</h3><input type="text" value="<?php echo("$name"); ?>"></input><br>
								<h3>Nazwisko</h3><input type="text" value="<?php echo("$surname"); ?>"></input><br>
								<h3>Data wynaęcia</h3><input type="date"></input><br>
								<h3>Godzina wynajęcia</h3> <input type="time"></input><br>
								<h3>Numer rejestracyjny</h3> <input type="text" value="ABW-4021NG"><br>
							</div>
							<div style="padding-right: 20px;">
								<h3>Samochód</h3><input type="text" value="Honda NSX"></input><br>
								<h3>Data zwrotu</h3><input type="date"></input><br>
								<h3>Godzina zwrotu</h3><input type="time"></input><br>
								<h3>Wartość(za dobę)</h3><br>
								<h3>Ostateczna cena</h3><br>
							</div>
						</div>
						<br>
					</div>
					<div class="button">
						<button name="Wynajmuj" type="submit" style="border-radius: 50%; height: 75px; width: 75px;"><a href="Cabinet.php" style="text-decoration:none;color: black;text-shadow: black 0 0 1px; ">Wynajmuj</a></button>
					</div>
				</form>
	</div>

	</body>
</html>
